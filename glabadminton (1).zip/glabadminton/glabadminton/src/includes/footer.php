<!-- footer -->
<footer>
    <div id="contact" class="footer">
        <div class="container">
            <div class="row pdn-top-30">
                <div class="col-md-12 ">
                    <div class="footer-box">
                        <div class="headinga">
                            <h3>Playing Ground </h3>
                            <span>GLA UNIVERSITY IBM (BLOCK AB-5) & AUDITORIUM (Beside AB-7
                                Block)</span>
                            <p>(+91)9926215890
                                <br>badminton.coach@gla.ac.in
                            </p>
                        </div>
                        <ul class="location_icon">
                            <li> <a target="blank" href="https://www.youtube.com/channel/UC8zjJ_IPVJI0gXaPKP1WWZw"><i class="fa fa-youtube"></i></a></li>
                            <li> <a target="blank" href="https://instagram.com/badminton_gla?igshid=3g2h5p5ja3kv"><i class="fa fa-instagram"></i></a></li>

                        </ul>
                        <div class="menu-bottom">
                            <ul class="link">
                                <li><a href="index.php">Home</a> </li>
                                <li><a href="gallery.php">Gallery</a></li>
                                <li><a href="joinclub.php">Join Club</a></li>
                                <li><a href="#">Attandence</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="headinga">
                            <h3> </h3>
                            <span class="link"> <a href="tel:9455593295" style="color: rgb(0,255,0);" >Design and Developed by : metaeducator</a> </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end footer -->