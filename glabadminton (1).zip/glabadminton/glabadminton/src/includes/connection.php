<?php
$conn = mysqli_connect("db", "root", "example", "glabadminton");
